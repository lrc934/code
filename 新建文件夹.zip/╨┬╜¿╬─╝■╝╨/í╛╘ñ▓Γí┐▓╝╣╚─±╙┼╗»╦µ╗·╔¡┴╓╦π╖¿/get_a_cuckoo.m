%% Get a cuckoo and generate new solutions by ramdom walk
function s=get_a_cuckoo(s,star)
    % This is a random walk, which is less efficient
    % than Levy flights. In addition, the step size
    % should be a vector for problems with different scales.
    % Here is the simplified implementation for demo only!
    stepsize=0.05;
    s=star+stepsize*randn(size(s));