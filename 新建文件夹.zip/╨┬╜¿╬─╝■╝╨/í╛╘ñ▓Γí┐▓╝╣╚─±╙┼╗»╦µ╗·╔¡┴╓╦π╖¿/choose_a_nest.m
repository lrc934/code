%% Choose a nest randomly
function k=choose_a_nest(n,Kbest)
    k=floor(rand*n)+1;
    % Avoid the best
    if k==Kbest,
        k=mod(k+1,n)+1;
    end