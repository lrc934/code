%% Replace some (of the worst nests)
%% by constructing new solutions/nests
function s=emptyit(s)
    % Again the step size should be varied
    % Here is a simplified approach
    s=s+0.05*randn(size(s));